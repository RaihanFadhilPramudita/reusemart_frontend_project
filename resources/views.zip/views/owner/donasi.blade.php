@extends('layouts.app')

@section('title', 'Kelola Donasi')

@section('content')
<div class="flex">
  <x-owner-sidebar />

  <main class="flex-1 p-6">
    <div class="flex justify-between items-center mb-4">
      <h2 class="text-xl font-bold">Daftar Donasi</h2>
      <button onclick="bukaModal()" class="bg-green-600 text-white px-4 py-2 rounded">Tambah Donasi</button>
    </div>

    <div class="overflow-x-auto bg-white shadow rounded">
      <table class="min-w-full divide-y divide-gray-200">
        <thead class="bg-gray-100 text-left text-sm font-semibold">
          <tr>
            <th class="px-4 py-3">ID</th>
            <th class="px-4 py-3">Barang</th>
            <th class="px-4 py-3">Organisasi</th>
            <th class="px-4 py-3">Penerima</th>
            <th class="px-4 py-3">Tanggal</th>
            <th class="px-4 py-3">Status</th>
            <th class="px-4 py-3">Aksi</th>
          </tr>
        </thead>
        <tbody id="donasiList" class="text-sm divide-y divide-gray-200"></tbody>
      </table>
    </div>
  </main>
</div>

<!-- Modal Form Tambah / Edit Donasi -->
<div id="modalDonasi" class="fixed inset-0 bg-black bg-opacity-40 hidden items-center justify-center z-50">
  <div class="bg-white p-6 rounded-lg w-full max-w-2xl space-y-4">
    <h3 class="text-lg font-bold" id="modalTitle">Tambah Donasi</h3>
    <form id="formDonasi" class="grid grid-cols-2 gap-4">
      <input type="hidden" id="editIdDonasi">
      <input type="text" id="idBarang" placeholder="ID Barang" class="border px-3 py-2 rounded" required>
      <input type="text" id="idRequest" placeholder="ID Request" class="border px-3 py-2 rounded" required>
      <input type="text" id="namaPenerima" placeholder="Nama Penerima" class="border px-3 py-2 rounded" required>
      <input type="date" id="tanggalDonasi" class="border px-3 py-2 rounded" required>
      <select id="statusDonasi" class="border px-3 py-2 rounded" required>
        <option value="Disalurkan">Disalurkan</option>
        <option value="Pending">Pending</option>
      </select>
      <div class="col-span-2 flex justify-end space-x-2">
        <button type="button" onclick="tutupModal()" class="bg-gray-400 text-white px-4 py-2 rounded">Batal</button>
        <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded">Simpan</button>
      </div>
    </form>
  </div>
</div>
@endsection

@section('scripts')
<script>
  const headers = { Authorization: `Bearer ${localStorage.getItem('token')}` };

  async function fetchDonasi() {
    const res = await axios.get('/api/owner/donasi', { headers });
    const list = document.getElementById('donasiList');
    list.innerHTML = res.data.data.map(d => `
      <tr>
        <td class="px-4 py-2">${d.ID_DONASI}</td>
        <td class="px-4 py-2">${d.barang?.NAMA_BARANG || '-'}</td>
        <td class="px-4 py-2">${d.request_donasi?.organisasi?.NAMA_ORGANISASI || '-'}</td>
        <td class="px-4 py-2">${d.NAMA_PENERIMA}</td>
        <td class="px-4 py-2">${d.TANGGAL_DONASI}</td>
        <td class="px-4 py-2">${d.STATUS}</td>
        <td class="px-4 py-2 space-x-2">
          <button onclick="editDonasi(${d.ID_DONASI})" class="bg-yellow-400 text-white px-3 py-1 rounded">Edit</button>
          <button onclick="hapusDonasi(${d.ID_DONASI})" class="bg-red-600 text-white px-3 py-1 rounded">Hapus</button>
        </td>
      </tr>
    `).join('');
  }

  function bukaModal() {
    document.getElementById('modalDonasi').classList.remove('hidden');
    document.getElementById('formDonasi').reset();
    document.getElementById('editIdDonasi').value = '';
    document.getElementById('modalTitle').innerText = 'Tambah Donasi';
  }

  function tutupModal() {
    document.getElementById('modalDonasi').classList.add('hidden');
  }

  async function editDonasi(id) {
    const res = await axios.get(`/api/owner/donasi/${id}`, { headers });
    const d = res.data.data;
    document.getElementById('editIdDonasi').value = d.ID_DONASI;
    document.getElementById('idBarang').value = d.ID_BARANG;
    document.getElementById('idRequest').value = d.ID_REQUEST;
    document.getElementById('namaPenerima').value = d.NAMA_PENERIMA;
    document.getElementById('tanggalDonasi').value = d.TANGGAL_DONASI;
    document.getElementById('statusDonasi').value = d.STATUS;
    bukaModal();
    document.getElementById('modalTitle').innerText = 'Edit Donasi';
  }

  async function hapusDonasi(id) {
    if (confirm("Yakin ingin menghapus donasi ini?")) {
      await axios.delete(`/api/owner/donasi/${id}`, { headers });
      fetchDonasi();
    }
  }

  document.getElementById('formDonasi').addEventListener('submit', async function(e) {
    e.preventDefault();
    const id = document.getElementById('editIdDonasi').value;
    const data = {
      id_barang: idBarang.value,
      id_request: idRequest.value,
      nama_penerima: namaPenerima.value,
      tanggal_donasi: tanggalDonasi.value,
      status: statusDonasi.value
    };
    if (id) {
      await axios.put(`/api/owner/donasi/${id}`, data, { headers });
    } else {
      await axios.post('/api/owner/donasi', data, { headers });
    }
    tutupModal();
    fetchDonasi();
  });

  fetchDonasi();
</script>
@endsection
