@extends('layouts.app')

@section('title', 'History Donasi')

@section('content')
<div class="flex">
  <x-owner-sidebar />

  <main class="flex-1 p-6">
    <h2 class="text-xl font-bold mb-4">History Donasi per Organisasi</h2>
    <select id="organisasiSelect" class="mb-3 border rounded px-3 py-2"></select>
    <div id="history-donasi" class="bg-white shadow rounded overflow-x-auto"></div>
  </main>
</div>
@endsection

@section('scripts')
<script>
  const headers = { Authorization: `Bearer ${localStorage.getItem('token')}` };

  async function loadOrganisasi() {
    const res = await axios.get('/api/owner/organisasi', { headers });
    const select = document.getElementById('organisasiSelect');
    select.innerHTML = res.data.data.map(o => `<option value="${o.ID_ORGANISASI}">${o.NAMA_ORGANISASI}</option>`).join('');
    if (res.data.data.length) loadHistory(res.data.data[0].ID_ORGANISASI);
  }

  async function loadHistory(id) {
    const res = await axios.get(`/api/owner/donasi/history/${id}`, { headers });
    document.getElementById('history-donasi').innerHTML = res.data.data.map(d => `
      <div class="p-3 border-b">Barang ${d.barang.NAMA_BARANG} - Tgl: ${d.TANGGAL_DONASI} - Penerima: ${d.NAMA_PENERIMA}</div>
    `).join('');
  }

  document.getElementById('organisasiSelect').addEventListener('change', e => {
    loadHistory(e.target.value);
  });

  loadOrganisasi();
</script>
@endsection
