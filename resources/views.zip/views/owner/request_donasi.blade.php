@extends('layouts.app')

@section('title', 'Request Donasi')

@section('content')
<div class="flex bg-gray-100 min-h-screen overflow-hidden">
  <x-owner-sidebar />

  <main class="flex-1 min-w-0 p-6 overflow-auto">
    <h2 class="text-2xl font-bold text-gray-800 mb-6">Daftar Request Donasi</h2>

    <div id="request-donasi" class="bg-white shadow rounded-lg overflow-x-auto">
      <div class="p-4 text-center text-gray-500">Memuat data...</div>
    </div>
  </main>
</div>
@endsection

@section('scripts')
<script>
  document.addEventListener("DOMContentLoaded", () => {
    const token = localStorage.getItem('token');
    const baseUrl = 'http://localhost:8000/api/owner/request_donasi';

    async function loadRequests() {
      try {
        const res = await axios.get(baseUrl, {
          headers: { Authorization: `Bearer ${token}` }
        });

        const list = res.data.data || [];
        const container = document.getElementById('request-donasi');

        if (!list.length) {
          container.innerHTML = '<div class="p-4 text-gray-500">Tidak ada request donasi.</div>';
          return;
        }

        container.innerHTML = `
          <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-green-600 text-white">
              <tr>
                <th class="px-6 py-3 text-left text-sm font-semibold">Nama Organisasi</th>
                <th class="px-6 py-3 text-left text-sm font-semibold">ID Permohonan</th>
                <th class="px-6 py-3 text-left text-sm font-semibold">Nama Barang</th>
                <th class="px-6 py-3 text-left text-sm font-semibold">Deskripsi</th>
                <th class="px-6 py-3 text-left text-sm font-semibold">Status</th>
              </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
              ${list.map(item => `
                <tr class="hover:bg-gray-50">
                  <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-800">${item.organisasi?.NAMA_ORGANISASI || '-'}</td>
                  <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-800">${item.ID_REQUEST}</td>
                  <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-800">${item.NAMA_BARANG}</td>
                  <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-800">${item.DESKRIPSI}</td>
                  <td class="px-6 py-4 whitespace-nowrap text-sm">
                    <span class="inline-block px-2 py-1 text-xs font-medium rounded-full ${
                      item.STATUS_REQUEST === 'Menunggu' ? 'bg-yellow-100 text-yellow-800' : 'bg-green-100 text-green-800'
                    }">${item.STATUS_REQUEST}</span>
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        `;
      } catch (error) {
        const container = document.getElementById('request-donasi');
        container.innerHTML = `<div class="p-4 text-red-600">Gagal memuat data: ${error.message}</div>`;
      }
    }

    loadRequests();
  });
</script>
@endsection
