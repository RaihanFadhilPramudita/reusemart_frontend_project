@extends('layouts.public')

@section('title', 'Detail Barang')

@section('content')
<div class="max-w-4xl mx-auto p-6">
  <div id="detail" class="bg-white rounded shadow p-6"></div>

  <div class="mt-10">
    <h2 class="text-lg font-semibold mb-3">Produk Serupa</h2>
    <div id="produk-serupa" class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4"></div>
  </div>
</div>
@endsection

@section('scripts')
<script>
  const id = '{{ $id }}';

  async function loadDetailBarang() {
    try {
      const res = await axios.get(`http://localhost:8000/api/barang/${id}`);
      const b = res.data.data;

      const container = document.getElementById('detail');
      container.innerHTML = `
        <div class="grid md:grid-cols-2 gap-6">
          <img src="${b.GAMBAR_URL ?? '/img/default.jpg'}" alt="Gambar Barang" class="w-full h-72 object-cover rounded" />

          <div>
            <h1 class="text-2xl font-bold mb-2">${b.NAMA_BARANG}</h1>
            <div class="text-green-600 text-2xl font-bold mb-2">Rp${parseInt(b.HARGA).toLocaleString()}</div>
            
            <div class="grid gap-1 text-sm text-gray-700 mb-4">
              <div><strong>Kondisi:</strong> ${b.KONDISI ?? 'Baru'}</div>
              <div><strong>Kategori:</strong> ${b.kategori?.NAMA_KATEGORI ?? '-'}</div>
              <div><strong>Merek:</strong> ${b.MEREK ?? 'Brand Lokal'}</div>
              <div><strong>Stok Tersisa:</strong> ${b.STOK ?? '-'}</div>
              <div><strong>Berat:</strong> ${b.BERAT ?? '0'} Gram</div>
              <div><strong>Dikirim dari:</strong> Jawa Timur - Indonesia</div>
            </div>

            <div class="mb-2 text-gray-600">
              <strong>Status Garansi:</strong> <span class="font-semibold">${b.STATUS_GARANSI ? 'Masih Bergaransi' : 'Tidak Bergaransi'}</span>
            </div>

            <div class="flex gap-3 mt-4">
              <button onclick="beliBarang()" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">Beli Sekarang</button>
              <button class="border border-green-600 text-green-600 px-4 py-2 rounded hover:bg-green-100">Tambah Keranjang</button>
            </div>
          </div>
        </div>

        <!-- Deskripsi & Penilaian -->
        <div class="mt-8">
          <h2 class="text-lg font-semibold mb-2">Deskripsi Produk</h2>
          <div class="text-gray-700 mb-4">${b.DESKRIPSI || '-'}</div>

          <h2 class="text-lg font-semibold mb-2">Penilaian Produk</h2>
          <div class="flex items-center gap-2 text-yellow-500 text-sm mb-1">
            ★★★★★ <span class="text-gray-700 ml-2">${b.RATING ?? '5.0'} / 5</span>
          </div>
          <div class="text-sm text-gray-600">1 Penilaian - Mantap sekali bisa digunakan</div>
        </div>
      `;
    } catch (err) {
      document.getElementById('detail').innerHTML = '<p class="text-red-500">Gagal memuat detail barang.</p>';
      console.error(err);
    }
  }

  async function loadProdukSerupa() {
    try {
      const res = await axios.get(`http://localhost:8000/api/barang/${id}/similar`);
      const list = res.data.data;

      if (!list.length) return;

      const html = list.map(item => `
        <div class="bg-white shadow rounded p-2">
          <img src="${item.GAMBAR_URL || '/img/default.jpg'}" class="w-full h-28 object-cover rounded mb-1" />
          <div class="text-sm font-semibold truncate">${item.NAMA_BARANG}</div>
          <div class="text-green-600 font-bold text-sm">Rp${parseInt(item.HARGA).toLocaleString()}</div>
          <div class="text-xs text-gray-500">${item.STOK ?? '-'} Terjual</div>
          <div class="text-xs text-gray-500">Dikirim dari Jawa Timur</div>
        </div>
      `).join('');

      document.getElementById('produk-serupa').innerHTML = html;
    } catch (err) {
      console.error('Gagal memuat produk serupa:', err);
    }
  }

  function beliBarang() {
    const token = localStorage.getItem('token');
    if (!token) {
      window.location.href = '/login';
      return;
    }

    alert('Loading...');
  }

  loadDetailBarang();
  loadProdukSerupa();
</script>
@endsection
