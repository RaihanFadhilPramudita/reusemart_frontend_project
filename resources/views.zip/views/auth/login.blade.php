@extends('layouts.app')

@section('content')
<div class="min-h-screen flex items-center justify-center bg-gray-100">
  <div class="bg-white p-8 rounded shadow-md w-full max-w-md">
    <h2 class="text-2xl font-bold text-center text-green-700 mb-2">Login</h2>
    <p class="text-center text-sm mb-6">
      Belum punya akun?
      <a href="{{ url('/register') }}" class="text-green-600 font-semibold hover:underline">
        Daftar Sekarang
      </a>
    </p>

    <form id="loginForm" class="space-y-4">
      <div>
        <label class="block text-sm font-medium">Login Sebagai</label>
        <select name="role" class="w-full px-3 py-2 border rounded" required>
          <option value="pegawai">Pegawai</option>
          <option value="pembeli">Pembeli</option>
          <option value="penitip">Penitip</option>
          <option value="organisasi">Organisasi</option>
        </select>
      </div>

      <div>
        <label class="block text-sm font-medium">Username</label>
        <input type="text" name="username" class="w-full px-3 py-2 border rounded" required>
      </div>
      <div>
        <label class="block text-sm font-medium">Password</label>
        <input type="password" name="password" class="w-full px-3 py-2 border rounded" required>
      </div>
      <div class="text-sm text-right">
        <a href="{{ url('/lost-password') }}" class="text-gray-600 hover:text-green-600">
          Lupa Password?
        </a>
      </div>
      <button type="submit" class="w-full bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 transition-colors">Login</button>
    </form>

    <p id="error" class="text-red-600 text-sm mt-4 text-center hidden"></p>
  </div>
</div>

<script>
  document.getElementById('loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();

  const role = document.querySelector('[name=role]').value;
  const username = document.querySelector('[name=username]').value;
  const password = document.querySelector('[name=password]').value;
  const errorEl = document.getElementById('error');

  errorEl.classList.add('hidden');

  let endpoint = '';
  switch (role) {
    case 'pegawai':
      endpoint = 'http://localhost:8000/api/auth/pegawai/login';
      break;
    case 'pembeli':
      endpoint = 'http://localhost:8000/api/auth/pembeli/login';
      break;
    case 'penitip':
      endpoint = 'http://localhost:8000/api/auth/penitip/login';
      break;
    case 'organisasi':
      endpoint = 'http://localhost:8000/api/auth/organisasi/login';
      break;
    default:
      errorEl.textContent = 'Peran login tidak valid.';
      errorEl.classList.remove('hidden');
      return;
  }

  try {

    const loginPayload = {
      password
    };

    if (role === 'pegawai' || role === 'organisasi') {
      loginPayload.username = username;
    } else {
      loginPayload.email = username;
    }

    const res = await axios.post(endpoint, loginPayload);

    const { token, user: data, data: alt } = res.data;
    const user = data || alt;

    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(user));
    axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;

    if (role === 'pegawai') {
      const jabatan = user.jabatan?.NAMA_JABATAN;
      switch (jabatan) {
        case 'Admin':
          axios.defaults.baseURL = 'http://localhost:8000/api/admin';
          window.location.href = '/admin/organisasi';
          break;
        case 'Customer Service':
          axios.defaults.baseURL = 'http://localhost:8000/api/cs';
          window.location.href = '/cs/penitip';
          break;
        case 'Gudang':
          axios.defaults.baseURL = 'http://localhost:8000/api/gudang';
          window.location.href = '/gudang/dashboard';
          break;
        case 'Owner':
          axios.defaults.baseURL = 'http://localhost:8000/api/owner';
          window.location.href = '/owner/request_donasi';
          break;
        default:
          errorEl.textContent = `Jabatan "${jabatan}" tidak dikenali.`;
          errorEl.classList.remove('hidden');
          return;
      }
    } else if (role === 'organisasi'){
        axios.defaults.baseURL = 'http://localhost:8000/api/organisasi';
        window.location.href = '/organisasi/request';
    }
  } catch (err) {
    console.error(err);
    errorEl.textContent = 'Login gagal. Username/email atau password salah.';
    errorEl.classList.remove('hidden');
  }
});
</script>
@endsection
