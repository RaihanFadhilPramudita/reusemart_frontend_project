@extends('layouts.public')

@section('title', 'Beranda')

@section('content')
<div class="max-w-7xl mx-auto px-4 py-6">
  <h2 class="text-2xl font-bold mb-4">Produk Terbaru</h2>
  
  <div class="overflow-x-auto">
    <div id="barang-list" class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-6 min-w-[1000px]">
    </div>
  </div>
</div>
@endsection

@section('scripts')
<script>
  const container = document.getElementById('barang-list');

  async function loadBarang(keyword = '') {
    try {
      const url = keyword
        ? `http://localhost:8000/api/barang/search?q=${encodeURIComponent(keyword)}`
        : `http://localhost:8000/api/barang`;

      const res = await axios.get(url);
      const list = res.data.data?.data || res.data.data || [];

      if (!list.length) {
        container.innerHTML = '<div class="col-span-full text-gray-500">Tidak ada barang ditemukan.</div>';
        return;
      }

      container.innerHTML = list.map(item => `
        <div class="bg-white rounded shadow p-4 flex flex-col hover:shadow-md transition">
          <img src="${item.GAMBAR_URL || '/img/default.jpg'}" class="w-full h-40 object-cover rounded mb-2">
          <div class="font-bold truncate">${item.NAMA_BARANG}</div>
          <div class="text-green-600 font-bold">Rp${parseInt(item.HARGA).toLocaleString()}</div>
          <div class="text-gray-500 text-xs">Status: ${item.STATUS_BARANG}</div>
          <a href="/barang/${item.ID_BARANG}" class="mt-auto bg-green-600 text-white px-3 py-1 text-center rounded hover:bg-green-700 transition mt-3">Lihat Detail</a>
        </div>
      `).join('');
    } catch (err) {
      console.error("Gagal memuat data barang:", err);
    }
  }

  document.getElementById('searchButton').addEventListener('click', () => {
    const keyword = document.getElementById('searchInput').value.trim();
    loadBarang(keyword);
  });

  document.getElementById('searchInput').addEventListener('keypress', function (e) {
    if (e.key === 'Enter') {
      e.preventDefault();
      document.getElementById('searchButton').click();
    }
  });

  loadBarang();
</script>
@endsection